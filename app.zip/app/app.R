library(shiny)
shinyApp(ui=ui.R,server=server.R)
